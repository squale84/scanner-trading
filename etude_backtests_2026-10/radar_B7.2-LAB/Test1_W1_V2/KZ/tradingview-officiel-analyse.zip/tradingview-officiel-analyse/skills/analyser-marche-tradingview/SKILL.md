---
name: analyser-marche-tradingview
description: Analyser des marchés avec les données du serveur MCP officiel TradingView en lecture seule, y compris cotations, OHLCV, technique, actualités, fondamentaux, calendriers, listes et alertes existantes.
---

# Analyse TradingView en lecture seule

Utilise uniquement le serveur `tradingview-officiel` défini par ce plugin, avec l'URL officielle `https://mcp.tradingview.com/mcp`. L'authentification s'effectue par OAuth du serveur ; laisse le client effectuer l'enregistrement automatique si proposé. Ne demande jamais de mot de passe ou de jeton dans la conversation.

## Outils autorisés

Liste fermée : `list_watchlists`, `get_watchlist`, `get_ohlcv`, `get_economic_data`, `get_economic_symbols`, `search_symbols`, `get_symbol_data`, `get_symbol_data_batch`, `get_screener_columns`, `run_screener`, `get_technicals_rating`, `get_news`, `get_news_story`, `get_forecasts`, `get_financials`, `get_financial_history`, `get_documents`, `get_document_view`, `get_earnings_calendar`, `get_economic_calendar`, `get_dividends_calendar`, `list_alerts`, `get_alerts`, `get_alerts_log`.

Ne lance aucun autre outil de ce serveur, même si le serveur le qualifie de lecture seule. En particulier, `get_active_watchlist` peut activer ou créer une liste et est interdit. N'utilise jamais `create_watchlist`, `delete_watchlist`, `add_to_watchlist`, `remove_from_watchlist`, `update_watchlist`, `create_alert`, `update_alert`, `delete_alert`, `stop_alerts` ou `restart_alerts`. Toute nouvelle action est interdite par défaut jusqu'à vérification explicite de son absence d'effet sur le compte.

Si une demande nécessite une action exclue, explique que ce plugin est limité à la lecture. Pour les listes existantes, commence par `list_watchlists`, puis `get_watchlist` avec l'identifiant voulu. Pour les alertes, utilise `list_alerts`, `get_alerts` et `get_alerts_log`.

Avant de conclure une analyse, indique le symbole et la place de cotation, les unités de temps, l'heure et le fuseau des données, leur éventuel retard, puis sépare les observations des hypothèses. Ne présente pas les données retardées comme des cours exécutables en temps réel. Ne prétends pas que l'éditeur Pine, le Strategy Tester ou le Replay sont accessibles par ce serveur si leurs outils ne sont pas présents.
